function changePicture() {
	document.getElementById('picture-to-change')
				.src="puppy-1903313_640.jpg"
	document.getElementById('picture-to-change')
				.alt="A cute Golden Retriever Labrador puppy."
}