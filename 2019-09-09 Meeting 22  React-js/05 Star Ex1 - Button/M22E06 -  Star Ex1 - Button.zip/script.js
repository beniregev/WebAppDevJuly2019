class My6thComponent extends React.Component {
    render() {
        return (
            <div>
                <h1>My 6th React Component</h1>
                <button type="submit">Click Me!</button>
            </div>
        );
    }
}

ReactDOM.render(
    <My6thComponent/>,
    document.getElementById("root")
    );
    
