# jQuery Exercise - No Submission

### * Take html from moodle
### * Add 3 buttons:
#### 1) Button: Hide p
* hides all &lt;p&gt; element with class "hide"
* Hide &lt;p&gt; element with following hirarchy: main &gt; article &gt; section &gt; div

#### 2) Button: Show p

#### 3) ButtonL Toogle footer
* Toggle footer show/hide.

### More buttons for HTML manipulation:

* Button to change content of a &lt;p&gt; element
* Button to change image
* Button to change body bg color
* Button to toggle class to &lt;p&gt;