function submitLoginRegister() {
    return;
}